slider.noUiSlider.get();
